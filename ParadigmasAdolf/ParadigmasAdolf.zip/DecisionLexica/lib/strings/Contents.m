% STRINGS
%
% Files
%   strendswith   - Determines whether a string ends with a specified pattern
%   strjoin       - Creates a string by joining multiple terms
%   strsplit      - Splits a string into multiple terms
%   strsplit_re   - Splits a string into multiple terms with regex delimiter
%   strstartswith - Determines whether a string starts with a specified pattern
%   strgsub       - Replaces all substrings matching a specified pattern
