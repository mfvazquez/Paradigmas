function Salir(hd)
    FlushEvents;
    ListenChar(1);
    ShowCursor;
    Screen('CloseAll');
end